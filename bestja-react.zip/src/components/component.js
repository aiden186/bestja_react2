import React from 'react'

import styles from './component.module.css'

const AppComponent = (props) => {
  return <div className={styles['container']}></div>
}

export default AppComponent
